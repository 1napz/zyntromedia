"""
Poe AI Platform - FastAPI Backend
Zyntro AI Studio | CrystalCastle Project
"""

import os
import time
import random
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, List

from fastapi import FastAPI, HTTPException, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

# ─── Optional Redis (graceful fallback to in-memory) ───
try:
    import redis.asyncio as aioredis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("poe-platform")

# ─── Config ───────────────────────────────────────────
MOCK_MODE:      bool = os.getenv("MOCK_MODE", "true").lower() == "true"
REDIS_URL:      str  = os.getenv("REDIS_URL", "redis://localhost:6379")
POE_API_KEY:    str  = os.getenv("POE_API_KEY", "")
HOST:           str  = os.getenv("HOST", "0.0.0.0")
PORT:           int  = int(os.getenv("PORT", "8000"))

# ─── Token Config ──────────────────────────────────────
REGEN_INTERVAL_S: int   = 5          # seconds per regen cycle
REGEN_MIN:        int   = 4_000
REGEN_MAX:        int   = 8_000
SEED_GROWTH_PCT:  float = 0.10       # 10% monthly compounding
GOD_MODE_CAP:     int   = 10_000_000

# ─── In-Memory State (fallback when Redis unavailable) ─
_state = {
    "balance":     1_248_932,
    "seed_base":   700_000,
    "seed_months": 3,
    "chat_count":  0,
    "last_regen":  time.time(),
}

# ─── App ───────────────────────────────────────────────
app = FastAPI(
    title="Poe AI Platform",
    description="Multi-model AI orchestration with God Mode, auto-regen & seed tokens",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Redis helper ──────────────────────────────────────
_redis: Optional[object] = None

async def get_redis():
    global _redis
    if not REDIS_AVAILABLE or not REDIS_URL:
        return None
    if _redis is None:
        try:
            _redis = await aioredis.from_url(REDIS_URL, decode_responses=True)
            await _redis.ping()
            logger.info("✓ Redis connected")
        except Exception as e:
            logger.warning(f"Redis unavailable, using in-memory state: {e}")
            _redis = None
    return _redis

async def get_balance() -> int:
    r = await get_redis()
    if r:
        val = await r.get("poe:balance")
        return int(val) if val else _state["balance"]
    return _state["balance"]

async def set_balance(val: int) -> None:
    r = await get_redis()
    if r:
        await r.set("poe:balance", val)
    else:
        _state["balance"] = val

async def incr_balance(delta: int) -> int:
    r = await get_redis()
    if r:
        return await r.incrby("poe:balance", delta)
    _state["balance"] += delta
    return _state["balance"]

# ─── Schemas ───────────────────────────────────────────
class ChatRequest(BaseModel):
    message:    str             = Field(..., min_length=1, max_length=4000)
    model:      str             = Field("claude-sonnet-4-6", description="Model slug")
    mock:       bool            = Field(default=MOCK_MODE)
    session_id: Optional[str]  = None

class ChatResponse(BaseModel):
    reply:        str
    model:        str
    tokens_used:  int
    balance:      int
    latency_ms:   float
    mock:         bool

class RegenResponse(BaseModel):
    added:        int
    balance:      int
    timestamp:    str

class TokenStats(BaseModel):
    balance:      int
    seed_total:   int
    seed_base:    int
    seed_growth:  int
    regen_rate:   str

class CostRequest(BaseModel):
    api_calls:    int   = Field(..., ge=1, le=100_000)
    tier:         str   = Field("Standard")

class CostResponse(BaseModel):
    api_calls:    int
    poe_cost:     float
    openai_cost:  float
    savings_pct:  float
    tier:         str

# ─── Static data ───────────────────────────────────────
MODELS = [
    {"id": "gpt-5",          "name": "GPT-5",      "provider": "OpenAI",    "context_k": 200,    "tier": "Premium"},
    {"id": "claude-sonnet-4-6", "name": "Claude Sonnet 4.6", "provider": "Anthropic", "context_k": 200, "tier": "Standard"},
    {"id": "claude-opus-4-6",   "name": "Claude Opus 4.6",   "provider": "Anthropic", "context_k": 200, "tier": "Premium"},
    {"id": "gemini-2-5",     "name": "Gemini 2.5", "provider": "Google",    "context_k": 2000,   "tier": "Standard"},
    {"id": "llama-4",        "name": "Llama 4",    "provider": "Meta",      "context_k": 10_000, "tier": "Advanced"},
    {"id": "mistral-large",  "name": "Mistral L",  "provider": "Mistral",   "context_k": 128,    "tier": "Lite"},
]

PRICING_TIERS = [
    {"name": "Free",     "price_month": 0,      "tokens_mo": 3_000,       "context_k": 4},
    {"name": "Lite",     "price_month": 4.99,   "tokens_mo": 10_000,      "context_k": 16},
    {"name": "Standard", "price_month": 19.99,  "tokens_mo": 1_000_000,   "context_k": 128},
    {"name": "Premium",  "price_month": 34.99,  "tokens_mo": 2_000_000,   "context_k": 200},
    {"name": "Advanced", "price_month": 120.00, "tokens_mo": 12_500_000,  "context_k": None},
    {"name": "God",      "price_month": 999.00, "tokens_mo": GOD_MODE_CAP,"context_k": 1280, "god": True},
]

COST_PER_CALL = {
    "Free":     0.0000,
    "Lite":     0.0050,
    "Standard": 0.0103,
    "Premium":  0.0175,
    "Advanced": 0.0096,
    "God":      0.0099,
}
OPENAI_COST_PER_CALL = 0.074

MOCK_REPLIES = [
    "กำลังประมวลผลด้วย context window 1.28M tokens ครับ... ✓ เสร็จแล้ว",
    "RAG retrieval สำเร็จ — พบ 12 เอกสารที่เกี่ยวข้อง ใช้ไป {tokens} tokens",
    "God Mode activated — ประมวลผลด้วย GPT-5 + Claude 4.5 ensemble ✓",
    "วิเคราะห์เสร็จแล้วครับ — ต้องการให้อธิบายเพิ่มเติมส่วนไหนไหม?",
    "Token usage: {tokens} tokens • คงเหลือ: {balance} tokens ในเดือนนี้",
]

# ─── Routes ────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse, tags=["UI"])
async def serve_ui():
    """Serve the Poe AI Platform frontend."""
    html_path = os.path.join(os.path.dirname(__file__), "poe-ai-platform.html")
    if os.path.exists(html_path):
        return FileResponse(html_path, media_type="text/html")
    return HTMLResponse(content="""
        <html><body style="font-family:monospace;background:#0d0d0d;color:#a5b4fc;padding:2rem">
        <h1>Poe AI Platform</h1>
        <p>✓ API server running</p>
        <p><a href="/docs" style="color:#c084fc">→ Interactive API Docs</a></p>
        <p>Place <code>poe-ai-platform.html</code> in the same directory to serve the UI.</p>
        </body></html>
    """)


@app.get("/health", tags=["System"])
async def health():
    """Health check endpoint."""
    balance = await get_balance()
    return {
        "status":     "ok",
        "mock_mode":  MOCK_MODE,
        "redis":      REDIS_AVAILABLE and _redis is not None,
        "balance":    balance,
        "timestamp":  datetime.utcnow().isoformat() + "Z",
        "version":    "1.0.0",
    }


@app.post("/api/chat", response_model=ChatResponse, tags=["Chat"])
async def chat(req: ChatRequest):
    """
    Send a message and get an AI response.
    In mock mode, returns a simulated reply without API calls.
    """
    t0 = time.time()
    tokens_used = random.randint(180, 1200)
    balance = await get_balance()

    if balance < tokens_used and not req.mock:
        raise HTTPException(status_code=402, detail="Insufficient token balance")

    if req.mock or MOCK_MODE:
        template = random.choice(MOCK_REPLIES)
        reply = template.format(tokens=tokens_used, balance=balance - tokens_used)
        model_used = req.model + " (mock)"
    else:
        # Production path — integrate your Poe API client here
        # from poe_api_wrapper import AsyncPoeApi
        # client = AsyncPoeApi(POE_API_KEY)
        # reply = await client.send_message(req.model, req.message)
        raise HTTPException(
            status_code=501,
            detail="Live mode requires POE_API_KEY and poe-api-wrapper. Set MOCK_MODE=true to test."
        )

    new_balance = await incr_balance(-tokens_used)
    _state["chat_count"] += 1
    latency = (time.time() - t0) * 1000

    return ChatResponse(
        reply=reply,
        model=model_used,
        tokens_used=tokens_used,
        balance=new_balance,
        latency_ms=round(latency, 2),
        mock=req.mock or MOCK_MODE,
    )


@app.post("/api/tokens/regen", response_model=RegenResponse, tags=["Tokens"])
async def trigger_regen():
    """Manually trigger a token regeneration cycle (simulates 5s auto-regen)."""
    added = random.randint(REGEN_MIN, REGEN_MAX)
    new_balance = await incr_balance(added)
    _state["last_regen"] = time.time()
    logger.info(f"Regen: +{added} → balance={new_balance}")
    return RegenResponse(
        added=new_balance,
        balance=new_balance,
        timestamp=datetime.utcnow().isoformat() + "Z",
    )


@app.get("/api/tokens/balance", response_model=TokenStats, tags=["Tokens"])
async def token_stats():
    """Get current token balance and seed projection."""
    balance = await get_balance()
    base   = _state["seed_base"]
    months = _state["seed_months"]
    growth = int(base * SEED_GROWTH_PCT * months)
    return TokenStats(
        balance=balance,
        seed_total=base + growth,
        seed_base=base,
        seed_growth=growth,
        regen_rate=f"+{REGEN_MIN:,}–{REGEN_MAX:,} tokens / {REGEN_INTERVAL_S}s",
    )


@app.get("/api/models", tags=["Models"])
async def list_models():
    """List all available AI models."""
    return {"models": MODELS, "total": len(MODELS)}


@app.get("/api/pricing", tags=["Pricing"])
async def get_pricing(period: str = "month"):
    """
    Get pricing tiers.
    - `period`: `month` or `year` (year applies 20% discount)
    """
    discount = 0.80 if period == "year" else 1.0
    tiers = []
    for t in PRICING_TIERS:
        tier = dict(t)
        tier["price"] = round(t["price_month"] * discount, 2)
        tier["period"] = period
        tier["context_label"] = (
            f"{t['context_k']}K" if t.get("context_k") else "Unlimited"
        )
        tiers.append(tier)
    return {"tiers": tiers, "period": period}


@app.post("/api/cost", response_model=CostResponse, tags=["Cost"])
async def calculate_cost(req: CostRequest):
    """Calculate and compare costs vs OpenAI direct pricing."""
    ppc = COST_PER_CALL.get(req.tier, COST_PER_CALL["Standard"])
    poe_cost     = round(req.api_calls * ppc, 2)
    openai_cost  = round(req.api_calls * OPENAI_COST_PER_CALL, 2)
    savings_pct  = round((1 - poe_cost / openai_cost) * 100, 1) if openai_cost > 0 else 0
    return CostResponse(
        api_calls=req.api_calls,
        poe_cost=poe_cost,
        openai_cost=openai_cost,
        savings_pct=savings_pct,
        tier=req.tier,
    )


@app.get("/api/stats", tags=["System"])
async def platform_stats():
    """Live platform statistics."""
    balance = await get_balance()
    return {
        "models_online":    len(MODELS),
        "tokens_today":     balance,
        "active_users":     random.randint(18_000, 19_000),
        "chat_requests":    _state["chat_count"],
        "uptime_s":         int(time.time() - (_state.get("start_time", time.time()))),
        "mock_mode":        MOCK_MODE,
    }


# ─── Background: auto-regen every 5s ──────────────────
async def _auto_regen_loop():
    logger.info(f"Auto-regen started: +{REGEN_MIN}–{REGEN_MAX} tokens every {REGEN_INTERVAL_S}s")
    while True:
        await asyncio.sleep(REGEN_INTERVAL_S)
        added = random.randint(REGEN_MIN, REGEN_MAX)
        new_bal = await incr_balance(added)
        _state["last_regen"] = time.time()
        logger.debug(f"Auto-regen +{added} → {new_bal:,}")

@app.on_event("startup")
async def startup():
    _state["start_time"] = time.time()
    logger.info(f"🚀 Poe AI Platform starting — mock_mode={MOCK_MODE}")
    await get_redis()
    asyncio.create_task(_auto_regen_loop())

@app.on_event("shutdown")
async def shutdown():
    if _redis:
        await _redis.close()
    logger.info("Server shut down.")


# ─── Dev runner ────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host=HOST, port=PORT, reload=True, log_level="info")
