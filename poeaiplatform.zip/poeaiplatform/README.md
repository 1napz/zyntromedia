# Poe AI Platform — God Mode 👑

> Multi-model AI orchestration with auto-regen tokens, seed growth, and multi-channel integration  
> Built by **Zyntro AI Studio** | CrystalCastle Project

---

## 📦 โครงสร้างโปรเจกต์

```
poeaiplatform/
├── app.py                  # FastAPI backend (ทุก endpoint)
├── poe-ai-platform.html    # Frontend UI (single-file)
├── requirements.txt        # Python dependencies
├── Dockerfile              # Multi-stage production build
├── docker-compose.yml      # Stack: app + redis
├── .env.example            # ตัวอย่าง environment variables
└── README.md               # คู่มือนี้
```

---

## ⚡ Quick Start (3 นาที)

### วิธีที่ 1 — Python โดยตรง

```bash
# 1. ติดตั้ง dependencies
pip install -r requirements.txt

# 2. รันใน Mock Mode (ไม่ต้องใช้ API key)
MOCK_MODE=true uvicorn app:app --reload

# 3. เปิดเบราว์เซอร์
# UI   → http://localhost:8000
# Docs → http://localhost:8000/docs
```

### วิธีที่ 2 — Docker

```bash
# Build + run ในคำสั่งเดียว
docker build -t poe-platform .
docker run -p 8000:8000 -e MOCK_MODE=true poe-platform
```

### วิธีที่ 3 — Docker Compose (แนะนำ — รวม Redis)

```bash
docker compose up -d
```

---

## 🔧 Environment Variables

สร้างไฟล์ `.env` จาก template:

```bash
cp .env.example .env
```

| Variable       | Default       | คำอธิบาย                              |
|----------------|---------------|---------------------------------------|
| `MOCK_MODE`    | `true`        | `true` = ไม่เรียก API จริง           |
| `POE_API_KEY`  | —             | API key สำหรับ production mode        |
| `REDIS_URL`    | —             | `redis://localhost:6379` (optional)   |
| `HOST`         | `0.0.0.0`     | Bind address                          |
| `PORT`         | `8000`        | HTTP port                             |

---

## 🚀 API Endpoints

| Method | Path                   | คำอธิบาย                             |
|--------|------------------------|--------------------------------------|
| GET    | `/`                    | Frontend UI                          |
| GET    | `/health`              | Health check + system status         |
| POST   | `/api/chat`            | ส่งข้อความและรับ AI reply            |
| GET    | `/api/models`          | รายการ AI models ทั้งหมด             |
| GET    | `/api/pricing?period=` | Pricing tiers (month/year)           |
| POST   | `/api/cost`            | คำนวณค่าใช้จ่าย vs OpenAI           |
| GET    | `/api/tokens/balance`  | Token balance + seed projection      |
| POST   | `/api/tokens/regen`    | Trigger manual regeneration          |
| GET    | `/api/stats`           | Live platform statistics             |
| GET    | `/docs`                | Swagger UI (FastAPI auto-generated)  |

### ตัวอย่าง: Chat Request

```bash
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "สวัสดี ช่วยอธิบาย God Mode หน่อยได้ไหม",
    "model": "claude-sonnet-4-6",
    "mock": true
  }'
```

**Response:**
```json
{
  "reply": "God Mode activated — ประมวลผลด้วย GPT-5 + Claude 4.5 ensemble ✓",
  "model": "claude-sonnet-4-6 (mock)",
  "tokens_used": 843,
  "balance": 1247089,
  "latency_ms": 12.4,
  "mock": true
}
```

---

## 👑 God Mode Features

| Feature             | คำอธิบาย                                        |
|---------------------|-------------------------------------------------|
| **Auto-Regen**      | +4,000–8,000 tokens ทุก 5 วินาทีอัตโนมัติ     |
| **Seed Tokens**     | tokens ที่ไม่ได้ใช้ carry forward + 10%/เดือน |
| **10M+ Tokens/mo**  | Context window 1.28M tokens                    |
| **Edge State**      | Cloudflare KV + Upstash Redis < 5ms latency    |
| **Mock Mode**       | ทดสอบฟรี ไม่เสียค่า API                        |

---

## 🐳 Production Deploy

### Vercel / Railway / Render

```bash
# Set environment variables ใน dashboard แล้ว deploy จาก GitHub
# Build command: pip install -r requirements.txt
# Start command: uvicorn app:app --host 0.0.0.0 --port $PORT
```

### VPS / Ubuntu

```bash
# 1. Clone + setup
git clone <your-repo>
cd poeaiplatform
pip install -r requirements.txt

# 2. Setup systemd service
sudo tee /etc/systemd/system/poe-platform.service << EOF
[Unit]
Description=Poe AI Platform
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/poeaiplatform
Environment=MOCK_MODE=false
Environment=POE_API_KEY=your_key_here
ExecStart=uvicorn app:app --host 0.0.0.0 --port 8000 --workers 4
Restart=always

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl enable --now poe-platform
```

---

## 🔗 Channel Integrations

| Channel   | Library              | Status   |
|-----------|----------------------|----------|
| WhatsApp  | `requests` + webhook | ✓ Ready  |
| Telegram  | `aiogram`            | ✓ Ready  |
| Discord   | `discord.py`         | ✓ Ready  |
| LINE      | `linebot`            | Planned  |

---

## 📋 Tech Stack

- **Backend**: FastAPI + Uvicorn (Python 3.11)
- **Frontend**: Tailwind CSS v3 + Vanilla JS (single-file HTML)
- **State**: Redis (Upstash) / in-memory fallback
- **Deploy**: Docker, Vercel, Railway, VPS
- **CI/CD**: GitHub Actions (Zyntro-Media-AI org)

---

## 📄 License

MIT © 2025 Zyntro AI Studio

---

*Built with ❤️ as part of CrystalCastle workflow automation platform*
